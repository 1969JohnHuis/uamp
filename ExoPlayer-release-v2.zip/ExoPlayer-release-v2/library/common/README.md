# ExoPlayer common library module #

Common code used by other ExoPlayer modules.

## Links ##

* [Javadoc][]: Note that this Javadoc is combined with that of other modules.

[Javadoc]: https://exoplayer.dev/doc/reference/index.html

