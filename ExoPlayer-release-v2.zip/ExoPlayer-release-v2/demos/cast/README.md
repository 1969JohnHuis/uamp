# Cast demo application #

This folder contains a demo application that showcases ExoPlayer integration
with Google Cast.

Please see the [demos README](../README.md) for instructions on how to build and
run this demo.
